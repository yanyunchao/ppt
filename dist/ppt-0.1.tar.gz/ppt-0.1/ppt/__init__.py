from ppt.core import ppt
